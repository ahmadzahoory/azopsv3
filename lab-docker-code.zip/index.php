<!DOCTYPE HTML>

<html>
	<head>
		<title>Ahmad</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body class="landing">

		<!-- Banner -->
			<section id="banner">
				<h2>Azure LAB</h2>
				<p class="ui header center"><font color="yellow">Container IP Address <?=$_SERVER['SERVER_ADDR'] ?></p>
			</section>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>